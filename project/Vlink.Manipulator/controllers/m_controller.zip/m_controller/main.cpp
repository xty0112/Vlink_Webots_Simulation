#include "manipulator.h"
int main(int argc, char** argv) {
	Manipulator* manipulator = new Manipulator();
	manipulator->run();
}
void Manipulator::run() {
	while (step(timeStep)!=-1)
	{
		keyboard();
		sensor(Manipulator_L);
		sensor(Manipulator_R);
		inverse_kine(Manipulator_L);
		inverse_kine(Manipulator_R);
		dynamics(Manipulator_L);
		dynamics(Manipulator_R);
		angle_control(Manipulator_L);
		angle_control(Manipulator_R);

		//cout << "realtou0=" << Manipulator_L->J0->getTorqueFeedback() << endl;
		cout << "err1=" << (Manipulator_L->J1->getTorqueFeedback()- Manipulator_L->tou[1])/Manipulator_L->J1->getTorqueFeedback() << endl;
		cout << "err2=" << (Manipulator_L->J2->getTorqueFeedback() - Manipulator_L->tou[2]) / Manipulator_L->J2->getTorqueFeedback() << endl;
		for (size_t i = 0; i < 3; i++)
		{
		//cout << "tou" << i << "=" << Manipulator_L->tou[i] << endl;
		//cout << "exp_angle" << i << "=" << Manipulator_L->exp_angle[i] << endl;
		//cout << "angle" << i << "=" << Manipulator_L->angle[i]->get(typeP) << endl;
		}
		cout <<" "<< endl;
		for (size_t i = 0; i < 3; i++)
		{
			//cout << "pos" << i << "=" << Manipulator_L->exp_pos[i] << endl;
		}
		cout << "------------" << endl;
	}
}